# Task11 > 2025-08-10 7:27pm
https://universe.roboflow.com/giki-uue7v/task11-fhahj

Provided by a Roboflow user
License: CC BY 4.0

